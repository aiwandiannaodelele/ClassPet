var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/archives/[archiveId]/active/route.js")
R.c("server/chunks/[root-of-the-server]__f11e8f86._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_archives_[archiveId]_active_route_actions_5f931f79.js")
R.m(19067)
module.exports=R.m(19067).exports

var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/archives/[archiveId]/groups/route.js")
R.c("server/chunks/[root-of-the-server]__3c04fd56._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_archives_[archiveId]_groups_route_actions_842b0b7d.js")
R.m(72494)
module.exports=R.m(72494).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/archives/[archiveId]/route.js")
R.c("server/chunks/[root-of-the-server]__03eb75a0._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_archives_[archiveId]_route_actions_ab1e88a8.js")
R.m(2693)
module.exports=R.m(2693).exports

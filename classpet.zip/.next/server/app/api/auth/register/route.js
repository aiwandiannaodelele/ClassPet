var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__3c0a8088._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_register_route_actions_3564e727.js")
R.m(6706)
module.exports=R.m(6706).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/settings/route.js")
R.c("server/chunks/[root-of-the-server]__b18ae641._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_settings_route_actions_e6b769f8.js")
R.m(96964)
module.exports=R.m(96964).exports

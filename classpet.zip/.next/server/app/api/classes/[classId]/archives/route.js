var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/[classId]/archives/route.js")
R.c("server/chunks/[root-of-the-server]__a685cd04._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_classes_[classId]_archives_route_actions_528115f1.js")
R.m(68826)
module.exports=R.m(68826).exports

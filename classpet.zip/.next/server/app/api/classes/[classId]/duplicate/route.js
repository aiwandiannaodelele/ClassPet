var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/[classId]/duplicate/route.js")
R.c("server/chunks/[root-of-the-server]__61688d7d._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_classes_[classId]_duplicate_route_actions_3ef81505.js")
R.m(33919)
module.exports=R.m(33919).exports

var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/[classId]/groups/route.js")
R.c("server/chunks/[root-of-the-server]__97469aa3._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_classes_[classId]_groups_route_actions_4af1adae.js")
R.m(84578)
module.exports=R.m(84578).exports

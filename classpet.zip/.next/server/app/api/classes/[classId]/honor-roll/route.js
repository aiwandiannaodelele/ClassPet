var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/[classId]/honor-roll/route.js")
R.c("server/chunks/[root-of-the-server]__c1cb13b9._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_classes_[classId]_honor-roll_route_actions_07277cd4.js")
R.m(39543)
module.exports=R.m(39543).exports

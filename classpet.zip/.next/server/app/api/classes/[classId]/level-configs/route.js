var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/[classId]/level-configs/route.js")
R.c("server/chunks/[root-of-the-server]__f8a433fd._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_classes_[classId]_level-configs_route_actions_cbf7483a.js")
R.m(12394)
module.exports=R.m(12394).exports

var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/[classId]/products/[productId]/route.js")
R.c("server/chunks/[root-of-the-server]__cc5c08c5._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_classes_[classId]_products_[productId]_route_actions_fdc64ba7.js")
R.m(79986)
module.exports=R.m(79986).exports

var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/[classId]/products/route.js")
R.c("server/chunks/[root-of-the-server]__1f20997c._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_classes_[classId]_products_route_actions_b2806a23.js")
R.m(9822)
module.exports=R.m(9822).exports

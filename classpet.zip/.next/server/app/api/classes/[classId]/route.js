var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/[classId]/route.js")
R.c("server/chunks/[root-of-the-server]__51b661f6._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_classes_[classId]_route_actions_ac01f6f2.js")
R.m(92106)
module.exports=R.m(92106).exports

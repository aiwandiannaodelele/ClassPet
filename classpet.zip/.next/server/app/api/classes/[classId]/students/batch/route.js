var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/[classId]/students/batch/route.js")
R.c("server/chunks/[root-of-the-server]__3e5cacef._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_classes_[classId]_students_batch_route_actions_c9652acb.js")
R.m(1350)
module.exports=R.m(1350).exports

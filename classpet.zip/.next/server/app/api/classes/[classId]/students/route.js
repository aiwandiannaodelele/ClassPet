var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/[classId]/students/route.js")
R.c("server/chunks/[root-of-the-server]__17b7e02a._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_classes_[classId]_students_route_actions_f52bba0b.js")
R.m(96658)
module.exports=R.m(96658).exports

var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/classes/route.js")
R.c("server/chunks/[root-of-the-server]__7f550af3._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_classes_route_actions_19b4d1f3.js")
R.m(76683)
module.exports=R.m(76683).exports

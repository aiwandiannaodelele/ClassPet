var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/exchanges/route.js")
R.c("server/chunks/[root-of-the-server]__bb59422d._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_exchanges_route_actions_076491b9.js")
R.m(83511)
module.exports=R.m(83511).exports

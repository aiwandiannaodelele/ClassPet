var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/groups/[groupId]/route.js")
R.c("server/chunks/[root-of-the-server]__e214c7cc._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_groups_[groupId]_route_actions_2f9795e4.js")
R.m(75569)
module.exports=R.m(75569).exports

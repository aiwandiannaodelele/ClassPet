var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/groups/[groupId]/scores/route.js")
R.c("server/chunks/[root-of-the-server]__ffaa29a6._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_groups_[groupId]_scores_route_actions_438ec83e.js")
R.m(81579)
module.exports=R.m(81579).exports

var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/groups/[groupId]/students/route.js")
R.c("server/chunks/[root-of-the-server]__6eb981a7._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_groups_[groupId]_students_route_actions_6b295617.js")
R.m(76705)
module.exports=R.m(76705).exports

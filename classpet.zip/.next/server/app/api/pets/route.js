var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/pets/route.js")
R.c("server/chunks/[root-of-the-server]__8f4c574d._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_pets_route_actions_72f7cb1c.js")
R.m(15963)
module.exports=R.m(15963).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rules/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__3b6d5e46._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_rules_[id]_route_actions_f7a09729.js")
R.m(99561)
module.exports=R.m(99561).exports

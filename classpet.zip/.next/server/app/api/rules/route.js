var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/rules/route.js")
R.c("server/chunks/[root-of-the-server]__86818275._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_rules_route_actions_d5960abd.js")
R.m(28682)
module.exports=R.m(28682).exports

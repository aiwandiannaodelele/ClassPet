var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/scores/[scoreId]/route.js")
R.c("server/chunks/[root-of-the-server]__8bc2728b._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_scores_[scoreId]_route_actions_bc61f7bd.js")
R.m(27642)
module.exports=R.m(27642).exports

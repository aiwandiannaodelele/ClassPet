var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/scores/route.js")
R.c("server/chunks/[root-of-the-server]__03a26640._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_scores_route_actions_946c9a18.js")
R.m(96912)
module.exports=R.m(96912).exports

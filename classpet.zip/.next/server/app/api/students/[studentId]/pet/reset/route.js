var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/[studentId]/pet/reset/route.js")
R.c("server/chunks/[root-of-the-server]__9e26aee2._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_students_[studentId]_pet_reset_route_actions_b2b5b747.js")
R.m(59409)
module.exports=R.m(59409).exports

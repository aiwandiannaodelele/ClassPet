var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/[studentId]/pet/revive/route.js")
R.c("server/chunks/[root-of-the-server]__e639d6f2._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_students_[studentId]_pet_revive_route_actions_3ab7c6c4.js")
R.m(28711)
module.exports=R.m(28711).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/[studentId]/route.js")
R.c("server/chunks/[root-of-the-server]__1f5df536._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_students_[studentId]_route_actions_137926d3.js")
R.m(89081)
module.exports=R.m(89081).exports

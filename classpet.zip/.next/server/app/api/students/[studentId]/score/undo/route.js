var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/[studentId]/score/undo/route.js")
R.c("server/chunks/[root-of-the-server]__de68f771._.js")
R.c("server/chunks/src_lib_prisma_ts_44781013._.js")
R.c("server/chunks/_bec45ad6._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/ce889_server_app_api_students_[studentId]_score_undo_route_actions_ab76369d.js")
R.m(42679)
module.exports=R.m(42679).exports

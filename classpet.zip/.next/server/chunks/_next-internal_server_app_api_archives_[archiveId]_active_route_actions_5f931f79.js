module.exports=[93686,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_archives_%5BarchiveId%5D_active_route_actions_5f931f79.js.map
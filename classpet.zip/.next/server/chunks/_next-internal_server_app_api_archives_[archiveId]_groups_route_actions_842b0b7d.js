module.exports=[84821,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_archives_%5BarchiveId%5D_groups_route_actions_842b0b7d.js.map
module.exports=[35224,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_archives_%5BarchiveId%5D_route_actions_ab1e88a8.js.map
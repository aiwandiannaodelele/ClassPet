module.exports=[61003,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_settings_route_actions_e6b769f8.js.map
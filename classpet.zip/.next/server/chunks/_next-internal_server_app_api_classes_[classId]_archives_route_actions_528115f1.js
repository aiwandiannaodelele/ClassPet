module.exports=[34306,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_classes_%5BclassId%5D_archives_route_actions_528115f1.js.map
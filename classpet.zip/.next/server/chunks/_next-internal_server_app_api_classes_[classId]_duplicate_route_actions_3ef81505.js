module.exports=[46084,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_classes_%5BclassId%5D_duplicate_route_actions_3ef81505.js.map
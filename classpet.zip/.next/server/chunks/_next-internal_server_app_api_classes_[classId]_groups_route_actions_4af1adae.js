module.exports=[34916,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_classes_%5BclassId%5D_groups_route_actions_4af1adae.js.map
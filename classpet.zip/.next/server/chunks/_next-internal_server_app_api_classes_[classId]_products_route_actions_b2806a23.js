module.exports=[80115,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_classes_%5BclassId%5D_products_route_actions_b2806a23.js.map
module.exports=[67280,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_classes_%5BclassId%5D_route_actions_ac01f6f2.js.map
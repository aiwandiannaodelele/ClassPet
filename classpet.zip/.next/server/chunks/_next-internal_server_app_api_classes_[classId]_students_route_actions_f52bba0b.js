module.exports=[96180,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_classes_%5BclassId%5D_students_route_actions_f52bba0b.js.map
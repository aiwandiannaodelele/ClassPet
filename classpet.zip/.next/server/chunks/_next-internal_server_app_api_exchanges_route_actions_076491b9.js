module.exports=[3054,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_exchanges_route_actions_076491b9.js.map
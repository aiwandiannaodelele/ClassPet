module.exports=[46327,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_groups_%5BgroupId%5D_route_actions_2f9795e4.js.map
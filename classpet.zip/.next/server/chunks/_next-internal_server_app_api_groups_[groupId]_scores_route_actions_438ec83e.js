module.exports=[9620,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_groups_%5BgroupId%5D_scores_route_actions_438ec83e.js.map
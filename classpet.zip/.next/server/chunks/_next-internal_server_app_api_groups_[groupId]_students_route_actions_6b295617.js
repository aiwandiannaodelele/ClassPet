module.exports=[64901,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_groups_%5BgroupId%5D_students_route_actions_6b295617.js.map
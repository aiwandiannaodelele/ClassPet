module.exports=[79553,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_scores_%5BscoreId%5D_route_actions_bc61f7bd.js.map
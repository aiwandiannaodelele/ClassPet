module.exports=[30484,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_students_%5BstudentId%5D_route_actions_137926d3.js.map
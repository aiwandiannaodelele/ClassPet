module.exports=[79385,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_classes_%5BclassId%5D_honor-roll_route_actions_07277cd4.js.map
module.exports=[30437,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_classes_%5BclassId%5D_products_%5BproductId%5D_route_actions_fdc64ba7.js.map
module.exports=[59200,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_classes_%5BclassId%5D_students_batch_route_actions_c9652acb.js.map
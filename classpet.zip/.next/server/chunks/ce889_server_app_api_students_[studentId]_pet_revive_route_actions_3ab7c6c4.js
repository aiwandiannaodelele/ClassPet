module.exports=[51320,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_students_%5BstudentId%5D_pet_revive_route_actions_3ab7c6c4.js.map
module.exports=[51849,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_students_%5BstudentId%5D_score_undo_route_actions_ab76369d.js.map
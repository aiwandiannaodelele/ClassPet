module.exports=[79266,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_class_%5Bid%5D_page_actions_e1aef723.js.map
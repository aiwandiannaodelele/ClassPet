module.exports=[21851,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_student_%5Bid%5D_page_actions_ef8829b7.js.map
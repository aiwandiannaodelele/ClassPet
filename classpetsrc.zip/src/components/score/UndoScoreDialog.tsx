"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Undo, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";

interface Record {
  id: string;
  studentId: string;
  studentName: string;
  ruleName: string;
  score: number;
  category: string;
  createdAt: string;
}

interface UndoScoreDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  classId?: string;
}

export function UndoScoreDialog({ open, onOpenChange, classId }: UndoScoreDialogProps) {
  const router = useRouter();
  const [records, setRecords] = useState<Record[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && classId) {
      fetchRecords();
    }
  }, [open, classId]);

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/scores?classId=${classId}`);
      if (response.ok) {
        const data = await response.json();
        setRecords(data.slice(0, 20));
      }
    } catch (error) {
      console.error("Failed to fetch records:", error);
      toast.error("加载评价记录失败");
    } finally {
      setLoading(false);
    }
  };

  const handleUndo = async (recordId: string, studentId: string, score: number) => {
    try {
      const response = await fetch(`/api/scores/${recordId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        await fetch(`/api/students/${studentId}/score/undo`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ score }),
        });

        toast.success("撤回成功");
        fetchRecords();
        if (typeof window !== 'undefined' && (window as any).refreshStudentList) {
          (window as any).refreshStudentList();
        }
        setTimeout(() => {
          router.refresh();
        }, 100);
      } else {
        toast.error("撤回失败");
      }
    } catch (error) {
      console.error("Failed to undo score:", error);
      toast.error("撤回失败");
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      learning: "bg-blue-500",
      behavior: "bg-purple-500",
      health: "bg-green-500",
      other: "bg-amber-500",
    };
    return colors[category] || "bg-gray-500";
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Undo className="w-5 h-5" />
            撤回评价
          </DialogTitle>
          <DialogDescription>
            撤回最近的评价记录（只能撤回最近的评价）
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="py-12 text-center">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-muted-foreground" />
            <p className="text-muted-foreground mt-2">加载中...</p>
          </div>
        ) : records.length === 0 ? (
          <div className="py-12 text-center">
            <span className="text-4xl">📝</span>
            <p className="text-muted-foreground mt-2">暂无评价记录</p>
          </div>
        ) : (
          <ScrollArea className="max-h-[60vh]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>学生</TableHead>
                  <TableHead>规则</TableHead>
                  <TableHead>分类</TableHead>
                  <TableHead className="text-right">分数</TableHead>
                  <TableHead className="text-right">时间</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {records.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell className="font-medium">{record.studentName}</TableCell>
                    <TableCell>{record.ruleName}</TableCell>
                    <TableCell>
                      <Badge className={getCategoryColor(record.category)}>
                        {record.category}
                      </Badge>
                    </TableCell>
                    <TableCell className={`text-right font-bold ${record.score > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {record.score > 0 ? "+" : ""}{record.score}
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      {new Date(record.createdAt).toLocaleString("zh-CN")}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleUndo(record.id, record.studentId, record.score)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        )}
      </DialogContent>
    </Dialog>
  );
}

"use client";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RuleManagement } from "@/components/rule/RuleManagement";
import { GrowthSettings } from "./GrowthSettings";
import { DataManagement } from "./DataManagement";
import { HelpSection } from "./HelpSection";
import { ClassManagement } from "./ClassManagement";
import { AboutSection } from "./AboutSection";
import { Users, FileSpreadsheet, Settings as SettingsIcon } from "lucide-react";
import { ClassParamsSettings } from "./ClassParamsSettings";

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  classId?: string;
}

export function SettingsDialog({ open, onOpenChange, classId }: SettingsDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-slate-700" />
            班级设置与管理
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue={classId ? "students" : "help"} className="flex-1">
          <TabsList className="grid w-full grid-cols-8 mb-4">
            <TabsTrigger value="students" disabled={!classId}>学生名单</TabsTrigger>
            <TabsTrigger value="classParams" disabled={!classId}>班级参数设置</TabsTrigger>
            <TabsTrigger value="survivalParams" disabled={!classId}>生存与惩罚</TabsTrigger>
            <TabsTrigger value="rules" disabled={!classId}>加减分规则</TabsTrigger>
            <TabsTrigger value="growth" disabled={!classId}>成长设置</TabsTrigger>
            <TabsTrigger value="data" disabled={!classId}>数据管理</TabsTrigger>
            <TabsTrigger value="help">软件与帮助</TabsTrigger>
            <TabsTrigger value="about">关于软件</TabsTrigger>
          </TabsList>

          <TabsContent value="students" className="h-[60vh] overflow-y-auto">
            {classId ? <ClassManagement classId={classId} /> : null}
          </TabsContent>

          <TabsContent value="classParams" className="h-[60vh] overflow-y-auto">
            {classId ? <ClassParamsSettings classId={classId} showOnly="basic" /> : null}
          </TabsContent>

          <TabsContent value="survivalParams" className="h-[60vh] overflow-y-auto">
            {classId ? <ClassParamsSettings classId={classId} showOnly="survival" /> : null}
          </TabsContent>

          <TabsContent value="rules" className="h-[60vh]">
            {classId ? <RuleManagement classId={classId} /> : null}
          </TabsContent>

          <TabsContent value="growth">
            {classId ? <GrowthSettings classId={classId} /> : null}
          </TabsContent>

          <TabsContent value="data">
            {classId ? <DataManagement classId={classId} /> : null}
          </TabsContent>

          <TabsContent value="help">
            <HelpSection />
          </TabsContent>

          <TabsContent value="about">
            <AboutSection />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

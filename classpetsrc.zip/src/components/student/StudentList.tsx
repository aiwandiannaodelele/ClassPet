'use client';

import { motion } from 'framer-motion';
import { StudentCard } from './StudentCard';
import type { Pet, Student } from '@prisma/client';

interface StudentWithPet extends Student {
  pet: Pet | null;
}

interface StudentListProps {
  students: StudentWithPet[];
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
    },
  },
};

export function StudentList({ students }: StudentListProps) {
  if (students.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-slate-500">这个班级还没有学生哦，快去添加吧！</p>
      </div>
    );
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6"
    >
      {students.map((student) => (
        <StudentCard key={student.id} student={student} />
      ))}
    </motion.div>
  );
}

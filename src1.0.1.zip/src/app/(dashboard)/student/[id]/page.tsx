import { notFound } from "next/navigation";
import { ArrowLeft, Edit2, Medal, History, Trash2, Heart, HeartOff, ShieldAlert, Star, TrendingUp, Trophy, ArrowUpCircle, Crown, ShoppingBag, ClipboardList } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";
import { zhCN } from "date-fns/locale";
import { headers } from "next/headers";

interface StudentDetailPageProps {
  params: Promise<{ id: string }>;
}

async function getStudent(id: string) {
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  try {
    const headersList = await headers();
    const cookieHeader = headersList.get('cookie');

    const res = await fetch(`${baseUrl}/api/students/${id}`, { 
      cache: 'no-store',
      headers: cookieHeader ? { cookie: cookieHeader } : undefined
    });
    if (!res.ok) {
      if (res.status === 404) return null;
      throw new Error("Failed to fetch student");
    }
    return res.json();
  } catch (error) {
    console.error(error);
    return null;
  }
}

export default async function StudentDetailPage({ params }: StudentDetailPageProps) {
  const { id } = await params;
  const student = await getStudent(id);

  if (!student) {
    notFound();
  }

  const progressValue = student.score % 100;

  return (
    <div className="container mx-auto p-4 md:p-6 max-w-5xl space-y-6">
      <div className="flex flex-col md:flex-row gap-6">
        {/* 左侧：学生与宠物信息 */}
        <div className="w-full md:w-1/3 space-y-6">
          <Card>
            <CardContent className="pt-6 flex flex-col items-center text-center bg-white">
              <Avatar className="h-32 w-32 mb-4 border-4 border-amber-200 shadow-sm">
                {student.pet?.image ? (
                  <AvatarImage src={student.pet.image} alt={student.pet.name} className="object-cover" />
                ) : null}
                <AvatarFallback className="bg-amber-100 text-5xl">
                  {student.pet ? "🐾" : "👦"}
                </AvatarFallback>
              </Avatar>
              <h2 className="text-2xl font-bold text-slate-800">{student.name}</h2>
              <p className="text-muted-foreground mb-4">班级: {student.class?.name}</p>

              <div className="w-full space-y-4 text-left">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">总积分</span>
                    <span className="font-bold text-amber-600">{student.score}</span>
                  </div>
                  <Progress value={progressValue} className="h-2 bg-amber-100" indicatorClassName="bg-amber-500" />
                </div>

                {student.pet ? (
                  <>
                    <div className="space-y-2 pt-2 border-t">
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-slate-500">守护宠物</span>
                        <Badge variant="outline">{student.pet.name}</Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500">宠物等级</span>
                        <span className="font-bold">Lv. {student.pet.level}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500">健康值</span>
                        <span className={`font-bold ${student.pet.health > 20 ? 'text-green-600' : 'text-red-600'}`}>
                          {student.pet.health}/100
                        </span>
                      </div>
                      <Progress 
                        value={student.pet.health} 
                        className="h-2 bg-slate-100" 
                        indicatorClassName={student.pet.health > 20 ? "bg-green-500" : "bg-red-500"} 
                      />
                    </div>
                  </>
                ) : (
                  <div className="pt-2 border-t text-center text-sm text-slate-500">
                    尚未选择守护宠物
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 右侧：历史记录 */}
        <div className="w-full md:w-2/3">
          <Card className="h-full">
            <CardHeader>
              <CardTitle>历史记录</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="scores" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="scores">评价记录 ({student.records?.length || 0})</TabsTrigger>
                  <TabsTrigger value="exchanges">兑换记录 ({student.exchanges?.length || 0})</TabsTrigger>
                </TabsList>
                
                <TabsContent value="scores" className="mt-4">
                  <ScrollArea className="h-[500px] pr-4">
                    {student.records && student.records.length > 0 ? (
                      <div className="space-y-4">
                        {student.records.map((record: any) => (
                          <div key={record.id} className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">{record.rule?.name || '未知规则'}</span>
                                <Badge variant="secondary" className="text-xs">{record.rule?.category}</Badge>
                              </div>
                              <div className="text-xs text-muted-foreground mt-1">
                                {format(new Date(record.createdAt), "yyyy年MM月dd日 HH:mm", { locale: zhCN })}
                              </div>
                            </div>
                            <div className={`font-bold text-lg ${record.scoreChange > 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {record.scoreChange > 0 ? '+' : ''}{record.scoreChange}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-muted-foreground py-20">
                        <ClipboardList className="w-10 h-10 mb-2 opacity-50" />
                        <p>暂无评价记录</p>
                      </div>
                    )}
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="exchanges" className="mt-4">
                  <ScrollArea className="h-[500px] pr-4">
                    {student.exchanges && student.exchanges.length > 0 ? (
                      <div className="space-y-4">
                        {student.exchanges.map((exchange: any) => (
                          <div key={exchange.id} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className="text-2xl">{exchange.product?.icon || '🎁'}</div>
                              <div>
                                <div className="font-medium">{exchange.product?.name || '未知商品'}</div>
                                <div className="text-xs text-muted-foreground mt-1">
                                  {format(new Date(exchange.createdAt), "yyyy年MM月dd日 HH:mm", { locale: zhCN })}
                                </div>
                              </div>
                            </div>
                            <div className="font-bold text-red-600">
                              -{exchange.product?.price || 0} 积分
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-muted-foreground py-20">
                        <ShoppingBag className="w-10 h-10 mb-2 opacity-50" />
                        <p>暂无兑换记录</p>
                      </div>
                    )}
                  </ScrollArea>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth/auth";

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ scoreId: string }> }
) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { scoreId } = await params;

    const targetRecord = await prisma.record.findUnique({
      where: { id: scoreId }
    });

    if (!targetRecord || targetRecord.teacherId !== session.user.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    await prisma.record.delete({
      where: { id: scoreId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting score:", error);
    return NextResponse.json(
      { error: "Failed to delete score" },
      { status: 500 }
    );
  }
}

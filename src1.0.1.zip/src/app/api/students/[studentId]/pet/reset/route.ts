import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth/auth";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ studentId: string }> }
) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { studentId } = await params;

    // 获取学生
    const student = await prisma.student.findUnique({
      where: { id: studentId },
      include: { pet: true, class: true },
    });

    if (!student || !student.pet || student.class.teacherId !== session.user.id) {
      return NextResponse.json(
        { error: "Student or Pet not found, or Forbidden" },
        { status: 404 }
      );
    }

    // 重新领养：成长值归零，删除宠物记录
    // 注意：根据规则，重新领养是"成长值从0开始，初始宠物"，意味着需要删除旧宠物，之后用户可以重新选择
    // 惩罚逻辑根据死亡次数 (reviveCount)
    let penaltyEndDate = student.penaltyEndDate;
    let penaltyDays = 0;
    let newDailyLimit = student.class.dailyScoreLimit || 20;

    // 根据消亡次数决定惩罚（这里用 reviveCount 作为死亡次数的近似，或者我们可以认为只要重新领养就是一次消亡）
    // 文档规则：
    // 第1次消亡：重新领养无额外惩罚 (如果负分有3天惩罚)
    // 第2次消亡：重新领养后1周内单日加分上限降至10分
    // 第3次消亡：永久锁定复活，重新领养2周内上限降至10分
    
    // 如果宠物是死的，说明这是一次消亡导致的重新领养
    if (student.pet.isDead) {
      if (student.pet.reviveCount === 1) { // 之前复活过1次，现在是第2次死
        penaltyDays = 7;
        newDailyLimit = 10;
      } else if (student.pet.reviveCount >= 2) { // 之前复活过2次以上，现在是第3次死
        penaltyDays = 14;
        newDailyLimit = 10;
      } else if (student.score < 0) { // 第1次死，但负分
        penaltyDays = 3;
      }
    } else if (student.score < 0) {
      // 活着但是主动重置，负分也给惩罚
      penaltyDays = 3;
    }

    if (penaltyDays > 0) {
      penaltyEndDate = new Date();
      penaltyEndDate.setDate(penaltyEndDate.getDate() + penaltyDays);
    }

    // 1. 删除旧宠物
    await prisma.pet.delete({
      where: { id: student.pet.id },
    });

    // 2. 重置学生数据
    await prisma.student.update({
      where: { id: studentId },
      data: {
        score: 0,
        level: 1, // 重新领养回到0级(对应规则是0级，但目前默认是1级起步，这里先设为1，或根据实际情况调整)
        penaltyEndDate: penaltyEndDate,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error resetting pet:", error);
    return NextResponse.json(
      { error: "Failed to reset pet" },
      { status: 500 }
    );
  }
}

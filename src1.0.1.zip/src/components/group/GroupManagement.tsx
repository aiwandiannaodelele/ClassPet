import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Plus, Users, Trash2, Edit2, Check, X, Star, Settings } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { GroupScoreDialog } from "@/components/score/GroupScoreDialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface GroupManagementProps {
  classId: string;
  students: any[];
  onUpdate: () => void;
}

export function GroupManagement({ classId, students, onUpdate }: GroupManagementProps) {
  const router = useRouter();
  const [archives, setArchives] = useState<any[]>([]);
  const [selectedArchiveId, setSelectedArchiveId] = useState<string>("");
  const [loading, setLoading] = useState(true);
  
  const [isCreatingArchive, setIsCreatingArchive] = useState(false);
  const [newArchiveName, setNewArchiveName] = useState("");
  const [isEditingArchive, setIsEditingArchive] = useState(false);
  const [editingArchiveName, setEditingArchiveName] = useState("");

  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [editingGroupName, setEditingGroupName] = useState("");
  
  // Score dialog
  const [showScoreDialog, setShowScoreDialog] = useState(false);
  const [scoringGroup, setScoringGroup] = useState<{id: string, name: string} | null>(null);

  // Assign students dialog
  const [showAssignDialog, setShowAssignDialog] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  
  const [archiveToDelete, setArchiveToDelete] = useState<string | null>(null);
  const [groupToDelete, setGroupToDelete] = useState<string | null>(null);

  const fetchArchives = async () => {
    try {
      const res = await fetch(`/api/classes/${classId}/archives`);
      if (res.ok) {
        const data = await res.json();
        setArchives(data);
        if (data.length > 0 && !selectedArchiveId) {
          const active = data.find((a: any) => a.isActive) || data[0];
          setSelectedArchiveId(active.id);
        }
      }
    } catch (error) {
      console.error("Failed to fetch archives", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchArchives();
  }, [classId]);

  const selectedArchive = archives.find(a => a.id === selectedArchiveId);
  const groups = selectedArchive?.groups || [];

  const handleCreateArchive = async () => {
    if (!newArchiveName.trim()) return;
    try {
      const res = await fetch(`/api/classes/${classId}/archives`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newArchiveName.trim() })
      });
      if (res.ok) {
        const newArchive = await res.json();
        setNewArchiveName("");
        setIsCreatingArchive(false);
        setSelectedArchiveId(newArchive.id);
        fetchArchives();
        toast.success("方案创建成功");
      }
    } catch (error) {
      toast.error("创建失败");
    }
  };

  const handleUpdateArchive = async () => {
    if (!editingArchiveName.trim() || !selectedArchiveId) return;
    try {
      const res = await fetch(`/api/archives/${selectedArchiveId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: editingArchiveName.trim() })
      });
      if (res.ok) {
        setIsEditingArchive(false);
        fetchArchives();
        toast.success("方案重命名成功");
      }
    } catch (error) {
      toast.error("重命名失败");
    }
  };

  const handleDeleteArchive = async (archiveId: string) => {
    try {
      const res = await fetch(`/api/archives/${archiveId}`, { method: "DELETE" });
      if (res.ok) {
        if (selectedArchiveId === archiveId) {
          setSelectedArchiveId("");
        }
        fetchArchives();
        toast.success("方案已删除");
      }
    } catch (error) {
      toast.error("删除失败");
    } finally {
      setArchiveToDelete(null);
    }
  };

  const handleSetActiveArchive = async () => {
    if (!selectedArchiveId) return;
    try {
      const res = await fetch(`/api/archives/${selectedArchiveId}/active`, { method: "PUT" });
      if (res.ok) {
        fetchArchives();
        toast.success("已设为默认方案");
      }
    } catch (error) {
      toast.error("设置失败");
    }
  };

  const handleCreateGroup = async () => {
    if (!newGroupName.trim() || !selectedArchiveId) return;
    try {
      const res = await fetch(`/api/archives/${selectedArchiveId}/groups`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newGroupName.trim() })
      });
      if (res.ok) {
        setNewGroupName("");
        setIsCreatingGroup(false);
        fetchArchives();
        toast.success("小组创建成功");
      }
    } catch (error) {
      toast.error("创建失败");
    }
  };

  const handleUpdateGroup = async (groupId: string) => {
    if (!editingGroupName.trim()) return;
    
    try {
      const res = await fetch(`/api/groups/${groupId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: editingGroupName.trim() })
      });
      
      if (res.ok) {
        setEditingGroupId(null);
        fetchArchives();
        toast.success("更新成功");
      }
    } catch (error) {
      toast.error("更新失败");
    }
  };

  const handleDeleteGroup = async (groupId: string) => {
    try {
      const res = await fetch(`/api/groups/${groupId}`, {
        method: "DELETE"
      });
      
      if (res.ok) {
        fetchArchives();
        onUpdate(); // refresh students as they lose group
        toast.success("小组已删除");
      }
    } catch (error) {
      toast.error("删除失败");
    } finally {
      setGroupToDelete(null);
    }
  };

  const openAssignDialog = (groupId: string, currentStudentIds: string[]) => {
    setSelectedGroupId(groupId);
    setSelectedStudentIds(currentStudentIds);
    setShowAssignDialog(true);
  };

  const handleAssignStudents = async () => {
    if (!selectedGroupId) return;
    
    try {
      const res = await fetch(`/api/groups/${selectedGroupId}/students`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentIds: selectedStudentIds })
      });
      
      if (res.ok) {
        setShowAssignDialog(false);
        fetchArchives();
        onUpdate(); // refresh students in parent
        toast.success("成员分配成功");
      } else {
        throw new Error();
      }
    } catch (error) {
      toast.error("分配失败");
    }
  };

  const toggleStudentSelection = (studentId: string) => {
    setSelectedStudentIds(prev => 
      prev.includes(studentId) 
        ? prev.filter(id => id !== studentId)
        : [...prev, studentId]
    );
  };

  if (loading) {
    return <div className="py-10 text-center text-muted-foreground">加载中...</div>;
  }

  // Get student ID to group mapping for the currently selected archive
  const studentToGroupMap = new Map<string, string>();
  groups.forEach((g: any) => {
    g.students.forEach((s: any) => {
      studentToGroupMap.set(s.id, g.id);
    });
  });

  return (
    <div className="space-y-6 mt-4">
      {/* Archive Selection and Management */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/50 p-4 rounded-xl border border-slate-200/60 shadow-sm backdrop-blur-md">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          {archives.length > 0 ? (
            <>
              {isEditingArchive ? (
                <div className="flex items-center gap-2">
                  <Input 
                    value={editingArchiveName} 
                    onChange={(e) => setEditingArchiveName(e.target.value)}
                    className="h-9 w-[200px]"
                    autoFocus
                  />
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-green-600" onClick={handleUpdateArchive}>
                    <Check className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-400" onClick={() => setIsEditingArchive(false)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <>
                  <Select value={selectedArchiveId} onValueChange={setSelectedArchiveId}>
                    <SelectTrigger className="w-[200px] h-10 bg-white">
                      <SelectValue placeholder="选择分组方案" />
                    </SelectTrigger>
                    <SelectContent>
                      {archives.map(archive => (
                        <SelectItem key={archive.id} value={archive.id}>
                          <div className="flex items-center gap-2">
                            {archive.name}
                            {archive.isActive && <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4">默认</Badge>}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  {selectedArchive && !selectedArchive.isActive && (
                    <Button variant="outline" size="sm" onClick={handleSetActiveArchive} className="h-10">
                      设为默认
                    </Button>
                  )}
                  
                  {selectedArchive && (
                    <div className="flex items-center">
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-500" onClick={() => { setEditingArchiveName(selectedArchive.name); setIsEditingArchive(true); }} title="重命名方案">
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-500 hover:text-red-600" onClick={() => setArchiveToDelete(selectedArchiveId)} title="删除方案">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </>
              )}
            </>
          ) : (
            <span className="text-sm text-slate-500 italic">暂无分组方案</span>
          )}
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          {isCreatingArchive ? (
            <div className="flex items-center gap-2">
              <Input 
                placeholder="新方案名称..." 
                value={newArchiveName}
                onChange={(e) => setNewArchiveName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleCreateArchive()}
                className="h-9 w-[150px]"
                autoFocus
              />
              <Button size="sm" onClick={handleCreateArchive} disabled={!newArchiveName.trim()}>保存</Button>
              <Button variant="ghost" size="sm" onClick={() => { setIsCreatingArchive(false); setNewArchiveName(""); }}>取消</Button>
            </div>
          ) : (
            <Button variant="outline" onClick={() => setIsCreatingArchive(true)} className="h-10">
              <Plus className="mr-2 h-4 w-4" />
              新建方案
            </Button>
          )}

          {archives.length > 0 && selectedArchiveId && !isCreatingGroup && (
            <Button onClick={() => setIsCreatingGroup(true)} className="bg-amber-500 hover:bg-amber-600 text-white h-10 shadow-sm">
              <Plus className="mr-2 h-4 w-4" />
              新建小组
            </Button>
          )}
        </div>
      </div>

      {isCreatingGroup && (
        <Card className="border-amber-200 bg-amber-50/30">
          <CardContent className="pt-6 flex items-center gap-4">
            <Input 
              placeholder="输入小组名称..." 
              value={newGroupName}
              onChange={(e) => setNewGroupName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreateGroup()}
              autoFocus
            />
            <Button onClick={handleCreateGroup} disabled={!newGroupName.trim()}>保存</Button>
            <Button variant="ghost" onClick={() => { setIsCreatingGroup(false); setNewGroupName(""); }}>取消</Button>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {groups.map((group: any) => (
          <Card key={group.id} className="overflow-hidden border-slate-200/60 shadow-sm hover:border-amber-400 hover:shadow-md transition-all duration-200 rounded-xl bg-white/90 backdrop-blur-md group/card">
            <CardHeader className="bg-slate-50/50 border-b pb-4 pt-4 relative">
              <div className="flex items-center justify-between">
                {editingGroupId === group.id ? (
                  <div className="flex items-center gap-2 w-full">
                    <Input 
                      value={editingGroupName} 
                      onChange={(e) => setEditingGroupName(e.target.value)}
                      className="h-8"
                      autoFocus
                    />
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-green-600" onClick={() => handleUpdateGroup(group.id)}>
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-400" onClick={() => setEditingGroupId(null)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <>
                    <CardTitle className="text-lg flex items-center gap-2">
                      {group.name}
                      <Badge variant="secondary" className="font-normal">{group.students.length}人</Badge>
                    </CardTitle>
                    <div className="flex items-center gap-1">
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-slate-500" onClick={() => openAssignDialog(group.id, group.students.map((s: any) => s.id))} title="管理成员">
                        <Users className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => { setEditingGroupId(group.id); setEditingGroupName(group.name); }} title="重命名">
                        <Edit2 className="h-4 w-4 text-slate-500" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8 hover:text-red-600" onClick={() => setGroupToDelete(group.id)} title="删除">
                        <Trash2 className="h-4 w-4 text-slate-500 hover:text-red-600" />
                      </Button>
                    </div>
                  </>
                )}
              </div>
              <div className="text-sm font-medium mt-2 flex justify-between items-center">
                <span className="text-slate-500">小组总分</span>
                <span className="text-amber-600 font-bold text-lg">{group.students.reduce((acc: number, s: any) => acc + s.score, 0)} 分</span>
              </div>
            </CardHeader>
            <CardContent className="pt-4 flex flex-col justify-between">
              <div className="flex flex-wrap gap-2 mb-4 min-h-[60px]">
                {group.students.length > 0 ? (
                  group.students.map((student: any) => (
                    <Badge key={student.id} variant="outline" className="flex items-center gap-1 pl-1 py-1">
                      <Avatar className="h-4 w-4">
                        <AvatarFallback className="text-[8px] bg-amber-100">{student.name[0]}</AvatarFallback>
                      </Avatar>
                      {student.name}
                    </Badge>
                  ))
                ) : (
                  <span className="text-sm text-slate-400 italic">暂无成员</span>
                )}
              </div>
              <Button 
                className="w-full text-base font-bold bg-amber-500 hover:bg-amber-600 text-white h-12 rounded-xl shadow-sm" 
                onClick={() => { setScoringGroup({id: group.id, name: group.name}); setShowScoreDialog(true); }}
              >
                <Star className="mr-2 h-5 w-5 fill-current" />
                喂食
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {groups.length === 0 && !isCreatingGroup && selectedArchiveId && (
        <div className="text-center py-12 bg-slate-50 rounded-lg border border-dashed">
          <Users className="mx-auto h-12 w-12 text-slate-300 mb-3" />
          <h3 className="text-lg font-medium text-slate-900 mb-4">当前方案还没有创建任何小组</h3>
          <Button onClick={() => setIsCreatingGroup(true)}>立即创建小组</Button>
        </div>
      )}

      {/* Assign Students Dialog */}
      <Dialog open={showAssignDialog} onOpenChange={setShowAssignDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>分配小组成员</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <ScrollArea className="h-[300px] pr-4">
              <div className="space-y-4">
                {/* Currently in this group */}
                {students.filter(s => selectedStudentIds.includes(s.id)).length > 0 && (
                  <div>
                    <h4 className="mb-2 text-sm font-medium text-slate-500">已选成员</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {students.filter(s => selectedStudentIds.includes(s.id)).map(student => (
                        <div key={student.id} className="flex items-center space-x-2 border rounded-md p-2 bg-slate-50">
                          <Checkbox 
                            id={`s-${student.id}`} 
                            checked={true}
                            onCheckedChange={() => toggleStudentSelection(student.id)}
                          />
                          <label htmlFor={`s-${student.id}`} className="text-sm font-medium leading-none cursor-pointer flex-1 truncate">
                            {student.name}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Unassigned students */}
                {students.filter(s => !studentToGroupMap.has(s.id) && !selectedStudentIds.includes(s.id)).length > 0 && (
                  <div>
                    <h4 className="mb-2 text-sm font-medium text-slate-500">未分配学生</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {students.filter(s => !studentToGroupMap.has(s.id) && !selectedStudentIds.includes(s.id)).map(student => (
                        <div key={student.id} className="flex items-center space-x-2 border rounded-md p-2 hover:bg-slate-50">
                          <Checkbox 
                            id={`s-${student.id}`} 
                            checked={false}
                            onCheckedChange={() => toggleStudentSelection(student.id)}
                          />
                          <label htmlFor={`s-${student.id}`} className="text-sm font-medium leading-none cursor-pointer flex-1 truncate">
                            {student.name}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Students in other groups */}
                {students.filter(s => studentToGroupMap.has(s.id) && studentToGroupMap.get(s.id) !== selectedGroupId && !selectedStudentIds.includes(s.id)).length > 0 && (
                  <div>
                    <h4 className="mb-2 text-sm font-medium text-slate-500">其他小组学生 (选择将调离原组)</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {students.filter(s => studentToGroupMap.has(s.id) && studentToGroupMap.get(s.id) !== selectedGroupId && !selectedStudentIds.includes(s.id)).map(student => (
                        <div key={student.id} className="flex items-center space-x-2 border rounded-md p-2 hover:bg-slate-50 opacity-70">
                          <Checkbox 
                            id={`s-${student.id}`} 
                            checked={false}
                            onCheckedChange={() => toggleStudentSelection(student.id)}
                          />
                          <label htmlFor={`s-${student.id}`} className="text-sm font-medium leading-none cursor-pointer flex-1 truncate">
                            {student.name} <span className="text-[10px] text-slate-400">({groups.find((g: any) => g.id === studentToGroupMap.get(student.id))?.name})</span>
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAssignDialog(false)}>取消</Button>
            <Button onClick={handleAssignStudents}>保存成员</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Group Score Dialog */}
      {scoringGroup && (
        <GroupScoreDialog
          open={showScoreDialog}
          onOpenChange={setShowScoreDialog}
          groupId={scoringGroup.id}
          groupName={scoringGroup.name}
          classId={classId}
          onScoreComplete={() => {
            fetchArchives();
            if (typeof window !== 'undefined' && (window as any).refreshStudentList) {
              (window as any).refreshStudentList();
            }
            setTimeout(() => {
              router.refresh();
            }, 100);
          }}
        />
      )}

      {/* Delete Archive Confirmation Dialog */}
      <AlertDialog open={!!archiveToDelete} onOpenChange={(open) => !open && setArchiveToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确定要删除当前分组方案吗？</AlertDialogTitle>
            <AlertDialogDescription>
              删除方案后，该方案下的所有小组都将被移除。组内学生本身不会被删除。此操作不可撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => archiveToDelete && handleDeleteArchive(archiveToDelete)}
              className="bg-red-600 hover:bg-red-700"
            >
              确定删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Group Confirmation Dialog */}
      <AlertDialog open={!!groupToDelete} onOpenChange={(open) => !open && setGroupToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确定要删除此小组吗？</AlertDialogTitle>
            <AlertDialogDescription>
              删除后该小组将被移除，但组内学生本身不会被删除，他们将变为未分配状态。此操作不可撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => groupToDelete && handleDeleteGroup(groupToDelete)}
              className="bg-red-600 hover:bg-red-700"
            >
              确定删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

"use client";

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  icon: string;
  stock: number;
  description?: string;
}

interface StoreDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  classId?: string;
}

const categories = [
  { id: "food", name: "美食", icon: "🍔" },
  { id: "stationery", name: "文具", icon: "✏️" },
  { id: "entertainment", name: "娱乐", icon: "🎮" },
  { id: "privilege", name: "特权", icon: "⭐" },
  { id: "misc", name: "杂项", icon: "🎁" },
];

export function StoreDialog({ open, onOpenChange, classId }: StoreDialogProps) {
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && classId) {
      fetchProducts();
    }
  }, [open, classId]);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/classes/${classId}/products`);
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      }
    } catch (error) {
      console.error("Failed to fetch products:", error);
      toast.error("加载商品失败");
    } finally {
      setLoading(false);
    }
  };

  const handleExchange = async (product: Product) => {
    if (!classId) {
      toast.error("班级 ID 不存在");
      return;
    }

    try {
      const response = await fetch("/api/exchanges", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          classId,
          studentId: "student-id",
          productId: product.id,
          productName: product.name,
          price: product.price,
        }),
      });

      if (response.ok) {
        toast.success(`兑换 ${product.name} 成功！`);
        fetchProducts();
      } else {
        const error = await response.json();
        toast.error(error.error || "兑换失败");
      }
    } catch (error) {
      console.error("Failed to exchange product:", error);
      toast.error("兑换失败");
    }
  };

  const filteredProducts = selectedCategory === "all" 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <span className="text-2xl">🏪</span>
              宠物小商店
            </DialogTitle>
            <DialogDescription>
              学生每累计获得 10 点成长值即可自动兑换 1 个宠物币，使用宠物币兑换心仪的商品吧！
            </DialogDescription>
          </DialogHeader>

          <div className="flex items-center justify-between mb-4">
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
              <TabsList>
                <TabsTrigger value="all">全部</TabsTrigger>
                {categories.map((cat) => (
                  <TabsTrigger key={cat.id} value={cat.id}>
                    {cat.icon} {cat.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>

            <Button
              onClick={() => setShowAddProduct(true)}
            >
              <Plus className="w-4 h-4 mr-2" />
              添加商品
            </Button>
          </div>

          {loading ? (
            <div className="py-12 text-center flex-1">
              <Loader2 className="w-8 h-8 animate-spin mx-auto text-muted-foreground" />
              <p className="text-muted-foreground mt-2">加载中...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="py-12 text-center flex-1">
              <span className="text-4xl">📦</span>
              <p className="text-muted-foreground mt-2">暂无商品</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[60vh] overflow-y-auto flex-1 pr-2">
              {filteredProducts.map((product) => (
                <Card key={product.id}>
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <div className="text-4xl">{product.icon || "📦"}</div>
                        <div>
                          <h4 className="font-semibold">{product.name}</h4>
                          <p className="text-sm text-muted-foreground">{product.description}</p>
                        </div>
                      </div>
                      <Badge variant="secondary">{product.category}</Badge>
                    </div>
                    <div className="flex items-center justify-between mt-4">
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold text-amber-600">{product.price}</span>
                        <span className="text-sm text-amber-700/70 font-medium">宠物币</span>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        库存：{product.stock === -1 ? "∞" : product.stock}
                      </div>
                    </div>
                    <Button className="w-full mt-3 bg-amber-500 hover:bg-amber-600 text-white" onClick={() => handleExchange(product)}>
                      兑换
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <AddProductDialog 
        open={showAddProduct} 
        onOpenChange={setShowAddProduct} 
        classId={classId}
        onSuccess={fetchProducts}
      />
    </>
  );
}

interface AddProductDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  classId?: string;
  onSuccess?: () => void;
}

function AddProductDialog({ open, onOpenChange, classId, onSuccess }: AddProductDialogProps) {
  const [productName, setProductName] = useState("");
  const [price, setPrice] = useState(10);
  const [stock, setStock] = useState(10);
  const [description, setDescription] = useState("");
  const [selectedIcon, setSelectedIcon] = useState("⭐");
  const [selectedCategory, setSelectedCategory] = useState("privilege");
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    if (!productName.trim()) {
      toast.error("请输入商品名称");
      return;
    }

    if (!classId) {
      toast.error("班级ID不存在");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/classes/${classId}/products`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: productName,
          price,
          stock,
          description,
          icon: selectedIcon,
          category: selectedCategory,
        }),
      });

      if (response.ok) {
        toast.success("商品添加成功！");
        onOpenChange(false);
        setProductName("");
        setPrice(10);
        setStock(10);
        setDescription("");
        setSelectedIcon("⭐");
        setSelectedCategory("privilege");
        onSuccess?.();
      } else {
        toast.error("添加商品失败");
      }
    } catch (error) {
      console.error("Failed to add product:", error);
      toast.error("添加商品失败");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5" />
            添加商品
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4 flex-1 overflow-y-auto pr-2">
          <div className="grid gap-2">
            <Label htmlFor="productName">商品名称</Label>
            <Input
              id="productName"
              placeholder="如：免作业卡"
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
            />
          </div>

          <div className="grid gap-2">
            <Label>价格（宠物币）</Label>
            <div className="flex items-center gap-2">
              <Input
                type="number"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-32"
              />
              <span className="text-muted-foreground">宠物币</span>
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="description">描述说明</Label>
            <Input
              id="description"
              placeholder="简单描述这个商品的作用..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div className="grid gap-2">
            <Label>商品分类</Label>
            <div className="flex gap-2 flex-wrap">
              {categories.map((cat) => (
                <Button
                  key={cat.id}
                  type="button"
                  variant={selectedCategory === cat.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setSelectedIcon(cat.icon);
                  }}
                >
                  {cat.icon} {cat.name}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="stock">库存数量</Label>
            <Input
              id="stock"
              type="number"
              value={stock}
              onChange={(e) => setStock(Number(e.target.value))}
            />
            <p className="text-xs text-muted-foreground">设置为 -1 代表无限库存</p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={handleSave} disabled={loading}>
            {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            保存更改
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

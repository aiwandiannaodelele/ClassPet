"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { PET_IMAGES } from "@/lib/constants/pets";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface ChoosePetDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  studentId: string;
  studentName: string;
  onPetSelected: (pet?: any) => void;
}

export function ChoosePetDialog({ open, onOpenChange, studentId, studentName, onPetSelected }: ChoosePetDialogProps) {
  const [selectedPet, setSelectedPet] = useState<{name: string, imageUrl: string} | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSelect = async () => {
    if (!selectedPet) {
      toast.error("请选择一个守护宠物");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/pets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          studentId,
          name: selectedPet.name,
          image: selectedPet.imageUrl,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        let errorMessage = "选择宠物失败";
        try {
          errorMessage = data.error || errorMessage;
        } catch {
          errorMessage = `请求失败 (${response.status})`;
        }
        throw new Error(errorMessage);
      }

      toast.success("守护宠物选择成功！");
      onPetSelected(data);
      onOpenChange(false);
    } catch (error) {
      console.error("Failed to choose pet:", error);
      toast.error(error instanceof Error ? error.message : "选择宠物失败");
    } finally {
      setLoading(false);
    }
  };

  const handleOpenChange = (isOpen: boolean) => {
    if (!isOpen) {
      setSelectedPet(null);
    }
    onOpenChange(isOpen);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>为 {studentName} 选择守护宠物</DialogTitle>
          <DialogDescription>
            请从下方列表中选择一个作为该学生的守护宠物。
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
            {PET_IMAGES.map((pet, index) => (
              <div
                key={index}
                className={`flex flex-col items-center justify-center p-2 rounded-xl cursor-pointer transition-all border-2 ${
                  selectedPet?.name === pet.name
                    ? "border-amber-500 bg-amber-50 scale-105 shadow-md"
                    : "border-transparent hover:border-amber-200 hover:bg-slate-50"
                }`}
                onClick={() => setSelectedPet(pet)}
              >
                <div className="h-16 w-16 mb-2 flex items-center justify-center">
                  <img src={pet.imageUrl} alt={pet.name} className="h-full w-full object-contain drop-shadow-sm" />
                </div>
                <span className="text-xs text-center font-medium text-slate-700">
                  {pet.name}
                </span>
              </div>
            ))}
          </div>
        </div>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={handleSelect} disabled={!selectedPet || loading}>
            {loading ? "提交中..." : "确定选择"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

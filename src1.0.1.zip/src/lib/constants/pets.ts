export const PET_IMAGES = [
  { name: "西高地", imageUrl: "/pets/westie.webp" },
  { name: "安哥拉兔", imageUrl: "/pets/angora-rabbit.webp" },
  { name: "比熊", imageUrl: "/pets/bichon.webp" },
  { name: "垂耳兔", imageUrl: "/pets/curl-ear-rabbit.webp" },
  { name: "柯尔鸭", imageUrl: "/pets/koel-duck.webp" },
  { name: "羊驼", imageUrl: "/pets/llama.webp" },
  { name: "边牧", imageUrl: "/pets/border-collie.webp" },
  { name: "柴犬", imageUrl: "/pets/shiba.webp" },
  { name: "虎斑猫", imageUrl: "/pets/tiger-striped-cat.webp" },
  { name: "加菲猫", imageUrl: "/pets/garfield.webp" },
  { name: "金毛", imageUrl: "/pets/golden-retriever.webp" },
  { name: "萨摩耶", imageUrl: "/pets/samoyed.webp" },
  { name: "白虎", imageUrl: "/pets/white-tiger.webp" },
  { name: "布偶猫", imageUrl: "/pets/ragdoll-cat.webp" },
  { name: "独角兽", imageUrl: "/pets/unicorn.webp" },
  { name: "多肉精灵", imageUrl: "/pets/succulent-spirit.webp" },
  { name: "哈士奇", imageUrl: "/pets/husky.webp" },
  { name: "橘猫", imageUrl: "/pets/orange-cat.webp" },
  { name: "貔貅", imageUrl: "/pets/pixiu.webp" },
  { name: "青龙", imageUrl: "/pets/azure-dragon.webp" },
  { name: "狻猊", imageUrl: "/pets/suanni.webp" },
  { name: "小熊猫", imageUrl: "/pets/red-panda.webp" },
  { name: "朱雀", imageUrl: "/pets/vermilion-bird.webp" }
];

// Fallback emojis in case images are missing
export const PET_EMOJIS = ["🐱", "🐶", "🐰", "🦊", "🐼", "🐨", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵", "🦄", "🐉", "🦆", "🦉", "🐧", "🐦"];

export function getRandomPetImage() {
  const randomIndex = Math.floor(Math.random() * PET_IMAGES.length);
  return PET_IMAGES[randomIndex].imageUrl;
}

export function getRandomPet() {
  const randomIndex = Math.floor(Math.random() * PET_IMAGES.length);
  return PET_IMAGES[randomIndex];
}

export function getRandomPetEmoji() {
  const randomIndex = Math.floor(Math.random() * PET_EMOJIS.length);
  return PET_EMOJIS[randomIndex];
}
